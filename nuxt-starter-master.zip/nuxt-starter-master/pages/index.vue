<template>
  <section class="text-yellow font-regular">
    test
  </section>
</template>

<script>
export default {}
</script>
